package com.axpe.axpe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AxpeApplicationTests {

	@Test
	void contextLoads() {
	}

}
