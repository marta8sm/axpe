package com.axpe.axpe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AxpeApplication {

	public static void main(String[] args) {
		SpringApplication.run(AxpeApplication.class, args);
	}

}
